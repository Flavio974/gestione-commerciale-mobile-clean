# Smart Assistant API

API backend per Smart Commercial Assistant.

## Setup su Replit:

1. **Crea nuovo Repl** su replit.com
2. **Seleziona "Import from GitHub"** o **"Upload files"**
3. **Carica tutti i file** di questa cartella
4. **Clicca "Run"**
5. **Copia l'URL pubblico** (sarà tipo: https://smart-assistant-api.tuousername.repl.co)

## File inclusi:
- `index.php` - Homepage con test
- `claude-ai.php` - API per AI
- `speech-to-text.php` - API per trascrizione
- `.htaccess` - Routing
- `.replit` - Configurazione Replit

Le API keys sono già incluse nel codice!