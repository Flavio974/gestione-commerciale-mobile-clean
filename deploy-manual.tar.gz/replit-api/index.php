<?php
// API Gateway per Smart Assistant
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

// Home page
if ($_SERVER['REQUEST_URI'] === '/' || $_SERVER['REQUEST_URI'] === '/index.php') {
    header('Content-Type: text/html');
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <title>Smart Assistant API</title>
        <style>
            body { font-family: Arial; padding: 40px; background: #f5f5f5; }
            .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .status { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0; }
            .endpoint { background: #f8f9fa; padding: 10px; margin: 10px 0; border-radius: 5px; font-family: monospace; }
            h1 { color: #333; }
            .test-btn { background: #457b9d; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 5px; }
            .test-btn:hover { background: #1d3557; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>🤖 Smart Assistant API</h1>
            <div class="status">✅ API Online e Funzionante!</div>
            
            <h2>Endpoints disponibili:</h2>
            <div class="endpoint">/api/claude-ai.php</div>
            <div class="endpoint">/api/speech-to-text.php</div>
            
            <h2>Test API:</h2>
            <button class="test-btn" onclick="testAPI('claude')">Test Claude AI</button>
            <button class="test-btn" onclick="testAPI('speech')">Test Speech-to-Text</button>
            
            <div id="results"></div>
            
            <script>
                async function testAPI(type) {
                    const results = document.getElementById('results');
                    results.innerHTML = '<p>Testing...</p>';
                    
                    try {
                        const url = type === 'claude' ? '/api/claude-ai.php?test' : '/api/speech-to-text.php?test';
                        const response = await fetch(url);
                        const data = await response.json();
                        results.innerHTML = '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
                    } catch (error) {
                        results.innerHTML = '<p style="color: red;">Error: ' + error.message + '</p>';
                    }
                }
            </script>
        </div>
    </body>
    </html>
    <?php
    exit();
}

// Se non è la home, lascia che .htaccess gestisca il routing
?>