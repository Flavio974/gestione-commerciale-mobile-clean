// Forza abilitazione vocale
localStorage.setItem('voice_enabled', 'true');
window.flavioAI.voiceEnabled = true;
console.log('✅ Funzioni vocali abilitate\!');
