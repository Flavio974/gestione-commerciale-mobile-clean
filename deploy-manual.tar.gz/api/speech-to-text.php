<?php
/**
 * Speech-to-Text API endpoint
 * Utilizza OpenAI Whisper per trascrivere audio
 */

// Configurazione CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

// Gestione richieste OPTIONS per CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configurazione API
$OPENAI_API_KEY = getenv('OPENAI_API_KEY') ?: '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';
$WHISPER_API_URL = 'https://api.openai.com/v1/audio/transcriptions';

// Log directory
$LOG_DIR = __DIR__ . '/logs/';
if (!file_exists($LOG_DIR)) {
    mkdir($LOG_DIR, 0755, true);
}

/**
 * Log delle richieste per debug
 */
function logRequest($type, $data) {
    global $LOG_DIR;
    $timestamp = date('Y-m-d H:i:s');
    $logFile = $LOG_DIR . 'speech-to-text-' . date('Y-m-d') . '.log';
    $logData = "[{$timestamp}] {$type}: " . json_encode($data) . PHP_EOL;
    file_put_contents($logFile, $logData, FILE_APPEND);
}

/**
 * Salva file audio temporaneo
 */
function saveAudioFile($audioData) {
    $tempDir = sys_get_temp_dir();
    
    // Rileva il formato dall'header base64
    $fileExt = '.webm'; // Default
    if (strpos($audioData, 'audio/mp3') !== false) {
        $fileExt = '.mp3';
    } elseif (strpos($audioData, 'audio/wav') !== false) {
        $fileExt = '.wav';
    } elseif (strpos($audioData, 'audio/ogg') !== false) {
        $fileExt = '.ogg';
    } elseif (strpos($audioData, 'audio/mpeg') !== false) {
        $fileExt = '.mp3';
    }
    
    $tempFile = $tempDir . '/audio_' . uniqid() . $fileExt;
    
    // Decodifica base64 se necessario
    if (strpos($audioData, 'base64,') !== false) {
        $audioData = explode('base64,', $audioData)[1];
    }
    
    $decodedData = base64_decode($audioData);
    if ($decodedData === false) {
        throw new Exception('Errore decodifica base64');
    }
    
    file_put_contents($tempFile, $decodedData);
    return $tempFile;
}

/**
 * Trascrivi audio usando OpenAI Whisper
 */
function transcribeAudio($audioFile) {
    global $OPENAI_API_KEY, $WHISPER_API_URL;
    
    // Rileva tipo MIME del file
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $audioFile);
    finfo_close($finfo);
    
    // Prepara il file per l'upload con tipo MIME corretto
    $cFile = new CURLFile($audioFile, $mimeType, basename($audioFile));
    
    $postData = [
        'file' => $cFile,
        'model' => 'whisper-1',
        'language' => 'it', // Italiano
        'response_format' => 'json',
        'temperature' => 0.2 // Più preciso
    ];
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $WHISPER_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $OPENAI_API_KEY
    ]);
    curl_setopt($ch, CURLOPT_TIMEOUT, 30);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    
    // Rimuovi file temporaneo
    unlink($audioFile);
    
    if ($error) {
        throw new Exception("Errore cURL: " . $error);
    }
    
    if ($httpCode !== 200) {
        throw new Exception("Errore API: HTTP " . $httpCode . " - " . $response);
    }
    
    $result = json_decode($response, true);
    if (!$result || !isset($result['text'])) {
        throw new Exception("Risposta API non valida");
    }
    
    return $result['text'];
}

// Gestione richiesta
try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception('Metodo non supportato');
    }
    
    // Leggi input
    $input = file_get_contents('php://input');
    $data = json_decode($input, true);
    
    if (!$data || !isset($data['audio'])) {
        throw new Exception('Audio mancante nella richiesta');
    }
    
    logRequest('REQUEST', [
        'method' => $_SERVER['REQUEST_METHOD'],
        'has_audio' => isset($data['audio']),
        'audio_size' => strlen($data['audio'])
    ]);
    
    // Salva audio temporaneo
    $audioFile = saveAudioFile($data['audio']);
    
    // Trascrivi audio
    $transcription = transcribeAudio($audioFile);
    
    // Risposta di successo
    $response = [
        'success' => true,
        'transcription' => $transcription,
        'timestamp' => date('c')
    ];
    
    logRequest('SUCCESS', $response);
    echo json_encode($response);
    
} catch (Exception $e) {
    $error = [
        'success' => false,
        'error' => $e->getMessage()
    ];
    
    logRequest('ERROR', $error);
    http_response_code(500);
    echo json_encode($error);
}
?>