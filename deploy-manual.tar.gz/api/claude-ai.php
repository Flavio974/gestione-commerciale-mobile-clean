<?php
/**
 * Backend PHP per gestire chiamate AI API (Claude + OpenAI)
 * Evita problemi CORS e protegge le API key
 */

// Configurazione CORS
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

// Gestione richieste OPTIONS per CORS preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Configurazione API
$ANTHROPIC_API_KEY = getenv('ANTHROPIC_API_KEY') ?: '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';
$OPENAI_API_KEY = getenv('OPENAI_API_KEY') ?: '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';
$SIMULATION_MODE = false; // Usa i dati REALI di Supabase sempre
$CLAUDE_API_URL = 'https://api.anthropic.com/v1/messages';
$OPENAI_API_URL = 'https://api.openai.com/v1/chat/completions';
$LOG_DIR = __DIR__ . '/logs/';

// Assicurati che la directory logs esista
if (!file_exists($LOG_DIR)) {
    mkdir($LOG_DIR, 0755, true);
}

// Test endpoint
if (isset($_GET['test'])) {
    echo json_encode([
        'status' => 'ok',
        'message' => 'Claude AI API endpoint is working',
        'timestamp' => date('Y-m-d H:i:s')
    ]);
    exit();
}

// Funzione per loggare l'utilizzo
function logUsage($tokens, $model, $cost) {
    global $LOG_DIR;
    $logFile = $LOG_DIR . 'ai_usage_' . date('Y-m') . '.json';
    
    $logEntry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'tokens' => $tokens,
        'model' => $model,
        'cost' => $cost,
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
    ];
    
    $logs = [];
    if (file_exists($logFile)) {
        $logs = json_decode(file_get_contents($logFile), true) ?: [];
    }
    
    $logs[] = $logEntry;
    file_put_contents($logFile, json_encode($logs, JSON_PRETTY_PRINT));
}

// Funzione per calcolare il costo approssimativo per entrambi i provider
function calculateCost($inputTokens, $outputTokens, $model) {
    // Prezzi approssimativi per 1M tokens (aggiorna secondo i prezzi attuali)
    $pricing = [
        // Claude models
        'claude-3-opus-20240229' => ['input' => 15.00, 'output' => 75.00],
        'claude-3-sonnet-20240229' => ['input' => 3.00, 'output' => 15.00],
        'claude-3-haiku-20240307' => ['input' => 0.25, 'output' => 1.25],
        'claude-2.1' => ['input' => 8.00, 'output' => 24.00],
        'claude-2.0' => ['input' => 8.00, 'output' => 24.00],
        
        // OpenAI models
        'gpt-4-turbo-preview' => ['input' => 10.00, 'output' => 30.00],
        'gpt-4' => ['input' => 30.00, 'output' => 60.00],
        'gpt-4-32k' => ['input' => 60.00, 'output' => 120.00],
        'gpt-3.5-turbo' => ['input' => 0.50, 'output' => 1.50],
        'gpt-3.5-turbo-16k' => ['input' => 3.00, 'output' => 4.00]
    ];
    
    $modelPricing = $pricing[$model] ?? $pricing['gpt-3.5-turbo'];
    
    $inputCost = ($inputTokens / 1000000) * $modelPricing['input'];
    $outputCost = ($outputTokens / 1000000) * $modelPricing['output'];
    
    return round($inputCost + $outputCost, 4);
}

// Funzione per determinare il provider dal modello
function getProviderFromModel($model) {
    if (strpos($model, 'claude') !== false) {
        return 'claude';
    } elseif (strpos($model, 'gpt') !== false) {
        return 'openai';
    }
    return 'openai'; // Default
}

// Funzione per costruire il prompt con contesto
function buildSystemPrompt($supabaseData, $isVoiceInput = false) {
    $context = "Sei Flavio AI Assistant, un assistente intelligente integrato nell'app web 'GestioneCommerciale-Mobile'.\n\n";
    $context .= "L'APP HA DIVERSE SCHEDE/TAB:\n";
    $context .= "- TIMELINE: Eventi, appuntamenti e attività programmate\n";
    $context .= "- CLIENTI: Gestione anagrafica clienti\n";
    $context .= "- ORDINI: Gestione ordini di vendita\n";
    $context .= "- DDT/FT: Documenti di trasporto e fatture\n";
    $context .= "- PERCORSI: Pianificazione itinerari\n";
    $context .= "- AI ASSISTANT: La scheda dove stai operando ora\n\n";
    $context .= "IMPORTANTE: Quando l'utente chiede 'cosa vedi nella scheda timeline' si riferisce ai dati degli eventi timeline che hai a disposizione nei dati Supabase.\n\n";
    
    if ($isVoiceInput) {
        $context .= "MODALITÀ VOCALE: L'utente ti ha parlato a voce. Rispondi in modo conversazionale e naturale. La tua risposta sarà pronunciata vocalmente.\n\n";
    } else {
        $context .= "MODALITÀ SCRITTA: NON usare prefissi come '*risponde in forma testuale*' o simili. NON iniziare con asterischi. Rispondi DIRETTAMENTE al messaggio dell'utente senza indicazioni di modalità.\n\n";
    }
    
    if (!empty($supabaseData)) {
        $context .= "Hai accesso ai seguenti dati aziendali in tempo reale:\n\n";
        
        if (isset($supabaseData['clients'])) {
            $context .= sprintf("- %d clienti totali\n", count($supabaseData['clients']));
            $topClients = array_slice($supabaseData['clients'], 0, 5);
            if (!empty($topClients)) {
                $context .= "  Top clienti: " . implode(', ', array_column($topClients, 'name')) . "\n";
            }
        }
        
        if (isset($supabaseData['orders'])) {
            $context .= sprintf("- %d ordini totali\n", count($supabaseData['orders']));
            $pendingOrders = array_filter($supabaseData['orders'], function($o) {
                return ($o['status'] ?? '') === 'pending';
            });
            $context .= sprintf("  Di cui %d in sospeso\n", count($pendingOrders));
        }
        
        if (isset($supabaseData['documents'])) {
            $context .= sprintf("- %d documenti (DDT/Fatture)\n", count($supabaseData['documents']));
        }
        
        if (isset($supabaseData['timeline'])) {
            $context .= sprintf("- %d eventi nella SCHEDA TIMELINE\n", count($supabaseData['timeline']));
        }
        
        if (isset($supabaseData['allEvents']) && is_array($supabaseData['allEvents'])) {
            $context .= sprintf("- %d eventi timeline totali (questi sono i dati della scheda timeline)\n", count($supabaseData['allEvents']));
            
            // Aggiungi dettagli sui primi eventi
            if (count($supabaseData['allEvents']) > 0) {
                $context .= "  Primi eventi timeline:\n";
                foreach (array_slice($supabaseData['allEvents'], 0, 3) as $event) {
                    $date = $event['date'] ?? 'N/A';
                    $title = $event['title'] ?? 'N/A';
                    $type = $event['type'] ?? 'N/A';
                    $context .= "    - $date: $title ($type)\n";
                }
            }
        }
        
        // DATI STORICI ORDINI - FONDAMENTALI PER ANALISI
        if (isset($supabaseData['historicalOrders']) && is_array($supabaseData['historicalOrders'])) {
            $historicalData = $supabaseData['historicalOrders'];
            $totalRecords = $historicalData['totalRecords'] ?? 0;
            $statistics = $historicalData['statistics'] ?? [];
            
            $context .= sprintf("- %d RECORD STORICI ORDINI dal database archivio_ordini_venduto\n", $totalRecords);
            
            if (isset($statistics['totalImporto'])) {
                $context .= sprintf("  Fatturato totale storico: €%s\n", number_format($statistics['totalImporto'], 2));
            }
            
            if (isset($statistics['numeroOrdini'])) {
                $context .= sprintf("  Ordini unici: %d\n", $statistics['numeroOrdini']);
            }
            
            if (isset($statistics['numeroClienti'])) {
                $context .= sprintf("  Clienti unici: %d\n", $statistics['numeroClienti']);
            }
            
            if (isset($statistics['topOrdini']) && !empty($statistics['topOrdini'])) {
                $topOrder = $statistics['topOrdini'][0];
                $context .= sprintf("  ORDINE VALORE PIÙ ALTO: €%s - %s (Ordine: %s)\n", 
                    number_format($topOrder['totaleImporto'], 2),
                    $topOrder['cliente'],
                    $topOrder['numeroOrdine']
                );
                
                // Aggiungi dettagli prodotti se disponibili
                if (isset($topOrder['dettagliProdotti']) && !empty($topOrder['dettagliProdotti'])) {
                    $context .= "    Prodotti in questo ordine:\n";
                    foreach (array_slice($topOrder['dettagliProdotti'], 0, 5) as $prodotto) {
                        $context .= sprintf("      - %s (Cod: %s) - Qta: %s - €%s\n",
                            $prodotto['nome'] ?? 'N/A',
                            $prodotto['codice'] ?? 'N/A', 
                            number_format($prodotto['qta'], 0),
                            number_format($prodotto['importoRiga'], 2)
                        );
                    }
                }
            }
        }
        
        // GESTIONE RICHIESTE PERCORSI FILTRATE
        if (isset($supabaseData['richiesta']) && $supabaseData['richiesta'] === 'tempo_di_viaggio') {
            if (isset($supabaseData['percorso']) && $supabaseData['percorso']) {
                $percorso = $supabaseData['percorso'];
                $context .= sprintf("- PERCORSO RICHIESTO: %s → %s = %d minuti (%s km)\n",
                    $percorso['partenza'],
                    $percorso['arrivo'], 
                    $percorso['minuti'],
                    $percorso['km'] ?? 'N/A'
                );
            } else {
                $context .= "- PERCORSO RICHIESTO: Non trovato nel database\n";
            }
        }
        
        // DATI PERCORSI generici (solo se non è una richiesta specifica)
        elseif (isset($supabaseData['percorsi']) && is_array($supabaseData['percorsi'])) {
            $totalPercorsi = count($supabaseData['percorsi']);
            $context .= sprintf("- %d PERCORSI disponibili per calcoli tempi di viaggio\n", $totalPercorsi);
        }
        
        $context .= "\nDati dettagliati disponibili:\n" . json_encode($supabaseData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }
    
    $context .= "\n\nREGOLA FONDAMENTALE: NON usare MAI prefissi come '*risponde in forma testuale*', '*modalità scritta*', '*risponde vocalmente*' o qualsiasi altro prefisso tra asterischi. Inizia SEMPRE le tue risposte direttamente con il contenuto.";
    $context .= "\nRispondi sempre in italiano e fornisci informazioni utili e pratiche per la gestione commerciale.";
    $context .= "\nSe ti vengono chieste analisi o statistiche, usa i dati forniti per dare risposte precise.";
    $context .= "\nSuggerisci azioni concrete quando appropriato.";
    $context .= "\nQuando rispondi a comandi vocali, usa un tono naturale e conversazionale, sapendo che l'utente ti sente parlare.";
    $context .= "\n\n🚨 REGOLE FONDAMENTALI PER TEMPI DI VIAGGIO:";
    $context .= "\n- Se è presente 'PERCORSO RICHIESTO' nei dati, usa ESATTAMENTE quel valore";
    $context .= "\n- Il sistema ha già filtrato e trovato il percorso specifico richiesto";
    $context .= "\n- Rispondi semplicemente con il tempo indicato";
    $context .= "\n- NON cercare in altri dati - usa SOLO il percorso fornito";
    $context .= "\n- Se il percorso non è trovato, comunica che non è disponibile nel database";
    
    $context .= "\n\nINFORMAZIONI IMPORTANTI SUI DATI:";
    $context .= "\n- I dati storici degli ordini sono nella struttura 'historicalOrders' con tutti i dettagli prodotti";
    $context .= "\n- Ogni ordine in 'topOrdini' contiene 'dettagliProdotti' con nome, codice, quantità e importo di ogni articolo";
    $context .= "\n- Puoi analizzare prodotti specifici, quantità vendute, prezzi unitari e fatturato per prodotto";
    $context .= "\n- I dati sono REALI dal database aziendale archivio_ordini_venduto";
    $context .= "\n- I percorsi sono nella struttura 'percorsi' con campi: partenza, arrivo, km, minuti, durata";
    $context .= "\n- ATTENZIONE: I percorsi sono mostrati nella sezione '⭐ PERCORSI CHIAVE' - usa ESATTAMENTE quei minuti";
    
    return $context;
}

// Funzione per generare risposte simulate INTELLIGENTI
function generateSimulatedResponse($message, $supabaseData) {
    $message = strtolower($message);
    
    // Analizza dati storici se disponibili
    $historicalData = $supabaseData['historicalOrders'] ?? null;
    $totalRecords = $historicalData['totalRecords'] ?? 0;
    $statistics = $historicalData['statistics'] ?? [];
    
    // DOMANDE SPECIFICHE SUI PRODOTTI E ORDINI
    if (strpos($message, 'prodotto') !== false && (strpos($message, 'valore') !== false || strpos($message, '943') !== false || strpos($message, 'alto') !== false)) {
        if (isset($statistics['topOrdini']) && !empty($statistics['topOrdini'])) {
            $topOrder = $statistics['topOrdini'][0];
            $prodottoPrincipale = $topOrder['prodottoPrincipale'] ?? ($topOrder['prodotti'][0] ?? 'N/A');
            $codiceProdotto = $topOrder['codicePrincipale'] ?? 'N/A';
            
            $response = "L'ordine dal valore di €" . number_format($topOrder['totaleImporto'], 2) . " si riferisce al prodotto **{$prodottoPrincipale}**";
            if ($codiceProdotto !== 'N/A') {
                $response .= " (codice {$codiceProdotto})";
            }
            $response .= ".\n\n";
            $response .= "Questo ordine è stato effettuato da **{$topOrder['cliente']}** con numero ordine **{$topOrder['numeroOrdine']}**.\n\n";
            
            if (isset($topOrder['dettagliProdotti']) && !empty($topOrder['dettagliProdotti'])) {
                $dettaglio = $topOrder['dettagliProdotti'][0];
                $response .= "Nel dettaglio:\n";
                $response .= "- Quantità: " . number_format($dettaglio['qta'], 0) . " pezzi\n";
                $response .= "- Prezzo unitario: €" . number_format($dettaglio['prezzo'], 2) . "\n";
                $response .= "- Importo totale: €" . number_format($topOrder['totaleImporto'], 2) . "\n\n";
            }
            
            $response .= "Si tratta del primo ordine per valore nella classifica dei top ordini del tuo database storico.";
            return $response;
        }
    }
    
    // TOP ORDINI
    if (strpos($message, 'top') !== false && strpos($message, 'ordini') !== false) {
        if (isset($statistics['topOrdini']) && !empty($statistics['topOrdini'])) {
            $response = "📊 **Top 5 Ordini per Valore:**\n\n";
            $topOrders = array_slice($statistics['topOrdini'], 0, 5);
            foreach ($topOrders as $i => $order) {
                $prodotto = $order['prodottoPrincipale'] ?? ($order['prodotti'][0] ?? 'N/A');
                $response .= ($i + 1) . ". **€" . number_format($order['totaleImporto'], 2) . "** - " . $order['cliente'] . "\n";
                $response .= "   Ordine: " . $order['numeroOrdine'] . " | Prodotto: " . $prodotto . "\n\n";
            }
            return $response;
        }
    }
    
    // TOP CLIENTI
    if (strpos($message, 'top') !== false && strpos($message, 'clienti') !== false) {
        if (isset($statistics['topClienti']) && !empty($statistics['topClienti'])) {
            $response = "👥 **Top 5 Clienti per Fatturato:**\n\n";
            $topClients = array_slice($statistics['topClienti'], 0, 5);
            foreach ($topClients as $i => $client) {
                $response .= ($i + 1) . ". **" . $client['cliente'] . "** - €" . number_format($client['fatturato'], 2) . "\n";
            }
            return $response;
        }
    }
    
    // FATTURATO TOTALE
    if (strpos($message, 'fatturato') !== false && strpos($message, 'totale') !== false) {
        if (isset($statistics['totalImporto'])) {
            $response = "💰 **Fatturato Totale:** €" . number_format($statistics['totalImporto'], 2) . "\n\n";
            $response .= "📊 **Statistiche:**\n";
            $response .= "- Record analizzati: " . number_format($totalRecords) . "\n";
            $response .= "- Ordini unici: " . ($statistics['numeroOrdini'] ?? 'N/A') . "\n";
            $response .= "- Clienti unici: " . ($statistics['numeroClienti'] ?? 'N/A') . "\n";
            $response .= "- Prodotti unici: " . ($statistics['numeroProdotti'] ?? 'N/A');
            return $response;
        }
    }
    
    // ANALISI VENDITE PRODOTTI SPECIFICI
    if (strpos($message, 'quanti') !== false && strpos($message, 'agnolotti') !== false) {
        // Simula l'analisi delle vendite degli AGNOLOTTI PLIN
        $response = "📦 **Analisi vendite AGNOLOTTI PLIN C ARNE ALFIERI 1000 G:**\n\n";
        $response .= "🔍 **Risultati trovati:**\n";
        $response .= "- **Quantità totale venduta:** 150 pezzi\n";
        $response .= "- **Numero ordini:** 3 ordini\n";
        $response .= "- **Fatturato totale:** €1.414,50\n";
        $response .= "- **Prezzo medio:** €9,43 per pezzo\n\n";
        
        $response .= "📋 **Dettaglio ordini:**\n";
        $response .= "1. **BOREALE SRL** - Ordine 507A085AS00712\n";
        $response .= "   • Quantità: 100 pezzi • Importo: €943,00\n\n";
        $response .= "2. **MAROTTA SRL** - Ordine 507A865AS02765\n";
        $response .= "   • Quantità: 30 pezzi • Importo: €283,00\n\n";
        $response .= "3. **ROSSINI & C.** - Ordine 507A945AS03201\n";
        $response .= "   • Quantità: 20 pezzi • Importo: €188,50\n\n";
        
        $response .= "📈 **Trend:** Prodotto molto richiesto, presente nel top ordini per valore!";
        return $response;
    }
    
    // ANALISI GENERICA PRODOTTI SPECIFICI
    if ((strpos($message, 'quanti') !== false || strpos($message, 'venduto') !== false) && 
        (strpos($message, 'prodotto') !== false || strpos($message, 'articolo') !== false)) {
        $response = "📊 **Per analisi dettagliate sui singoli prodotti,** specifica il nome completo.\n\n";
        $response .= "💡 **Esempio:** \"Quanti AGNOLOTTI PLIN C ARNE ALFIERI 1000 G ho venduto?\"\n\n";
        $response .= "🔍 **Posso analizzare:**\n";
        $response .= "• Quantità totali vendute\n";
        $response .= "• Fatturato per prodotto\n";
        $response .= "• Clienti che lo acquistano\n";
        $response .= "• Trend temporali\n\n";
        $response .= "📋 Cerca nei top prodotti o dimmi il nome specifico del prodotto!";
        return $response;
    }
    
    // QUANTI CLIENTI/ORDINI/PRODOTTI GENERICI
    if (strpos($message, 'quanti') !== false) {
        if (strpos($message, 'clienti') !== false && isset($statistics['numeroClienti'])) {
            return "👥 Ho trovato **" . $statistics['numeroClienti'] . " clienti unici** nei {$totalRecords} record del database.";
        }
        if (strpos($message, 'ordini') !== false && isset($statistics['numeroOrdini'])) {
            return "📋 Ho trovato **" . $statistics['numeroOrdini'] . " ordini unici** nei {$totalRecords} record del database.";
        }
        if (strpos($message, 'prodotti') !== false && isset($statistics['numeroProdotti'])) {
            return "📦 Ho trovato **" . $statistics['numeroProdotti'] . " prodotti unici** nei {$totalRecords} record del database.";
        }
    }
    
    // RISPOSTA GENERICA PIÙ UTILE
    $response = "🤖 **Modalità simulazione intelligente attiva**\n\n";
    $response .= "📊 Ho accesso a **{$totalRecords} record** con:\n";
    if (isset($statistics['numeroOrdini'])) $response .= "- " . $statistics['numeroOrdini'] . " ordini unici\n";
    if (isset($statistics['numeroClienti'])) $response .= "- " . $statistics['numeroClienti'] . " clienti unici\n";
    if (isset($statistics['numeroProdotti'])) $response .= "- " . $statistics['numeroProdotti'] . " prodotti unici\n";
    if (isset($statistics['totalImporto'])) $response .= "- €" . number_format($statistics['totalImporto'], 2) . " fatturato totale\n\n";
    
    $response .= "💡 **Prova a chiedere:**\n";
    $response .= "• \"Qual è il prodotto dell'ordine con valore più alto?\"\n";
    $response .= "• \"Mostrami i top 5 clienti\"\n";
    $response .= "• \"Quanto fatturato totale abbiamo?\"\n";
    $response .= "• \"Quanti ordini ci sono?\"";
    
    return $response;
}

// Gestione richiesta principale
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['message'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Messaggio richiesto']);
        exit();
    }
    
    $userMessage = $input['message'];
    $supabaseData = $input['supabaseData'] ?? [];
    $model = $input['model'] ?? 'gpt-3.5-turbo';
    $conversationHistory = $input['history'] ?? [];
    $isVoiceInput = $input['isVoiceInput'] ?? false;
    $provider = getProviderFromModel($model);
    
    // Debug log
    error_log("🔍 Backend ricevuto - isVoiceInput: " . ($isVoiceInput ? 'true' : 'false') . " - Message: " . $userMessage);
    
    // Costruisci il sistema prompt con i dati Supabase
    $systemPrompt = buildSystemPrompt($supabaseData, $isVoiceInput);
    
    // Modalità simulazione per test
    if ($SIMULATION_MODE) {
        $aiResponse = generateSimulatedResponse($userMessage, $supabaseData);
        
        echo json_encode([
            'response' => $aiResponse,
            'usage' => [
                'daily_cost' => 0.00,
                'monthly_cost' => 0.00,
                'total_tokens' => 100
            ],
            'simulation' => true
        ]);
        exit();
    }
    
    if ($provider === 'claude') {
        // Logica per Claude API
        $messages = [
            [
                'role' => 'user',
                'content' => $userMessage
            ]
        ];
        
        // Aggiungi la cronologia della conversazione se presente
        if (!empty($conversationHistory)) {
            $messages = array_merge($conversationHistory, $messages);
        }
        
        $requestData = [
            'model' => $model,
            'messages' => $messages,
            'system' => $systemPrompt,
            'max_tokens' => 2000,
            'temperature' => 0.7
        ];
        
        $ch = curl_init($CLAUDE_API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'x-api-key: ' . $ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01'
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            // Debug dettagliato per capire il problema
            $responseDetails = json_decode($response, true);
            
            error_log("🔍 CLAUDE API ERROR - HTTP Code: $httpCode");
            error_log("🔍 CLAUDE API ERROR - Response: " . $response);
            error_log("🔍 CLAUDE API ERROR - API Key (primi 20 char): " . substr($ANTHROPIC_API_KEY, 0, 20));
            
            http_response_code($httpCode);
            echo json_encode([
                'error' => "Errore Claude API (HTTP $httpCode)",
                'details' => $responseDetails,
                'debug' => [
                    'api_key_length' => strlen($ANTHROPIC_API_KEY),
                    'api_key_prefix' => substr($ANTHROPIC_API_KEY, 0, 20),
                    'model' => $model,
                    'provider' => $provider
                ]
            ]);
            exit();
        }
        
        $responseData = json_decode($response, true);
        
        if (isset($responseData['content'][0]['text'])) {
            $aiResponse = $responseData['content'][0]['text'];
            $usage = $responseData['usage'] ?? [];
            $inputTokens = $usage['input_tokens'] ?? 0;
            $outputTokens = $usage['output_tokens'] ?? 0;
        } else {
            http_response_code(500);
            echo json_encode([
                'error' => 'Risposta non valida da Claude API',
                'details' => $responseData
            ]);
            exit();
        }
        
    } else {
        // Logica per OpenAI API
        $messages = [
            [
                'role' => 'system',
                'content' => $systemPrompt
            ],
            [
                'role' => 'user', 
                'content' => $userMessage
            ]
        ];
        
        // Aggiungi la cronologia della conversazione se presente
        if (!empty($conversationHistory)) {
            $messages = array_merge([
                ['role' => 'system', 'content' => $systemPrompt]
            ], $conversationHistory, [
                ['role' => 'user', 'content' => $userMessage]
            ]);
        }
        
        $requestData = [
            'model' => $model,
            'messages' => $messages,
            'max_tokens' => 2000,
            'temperature' => 0.7
        ];
        
        $ch = curl_init($OPENAI_API_URL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($requestData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $OPENAI_API_KEY
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode !== 200) {
            // Debug dettagliato per OpenAI
            $responseDetails = json_decode($response, true);
            
            error_log("🔍 OPENAI API ERROR - HTTP Code: $httpCode");
            error_log("🔍 OPENAI API ERROR - Response: " . $response);
            error_log("🔍 OPENAI API ERROR - API Key (primi 20 char): " . substr($OPENAI_API_KEY, 0, 20));
            
            http_response_code($httpCode);
            echo json_encode([
                'error' => "Errore OpenAI API (HTTP $httpCode)",
                'details' => $responseDetails,
                'debug' => [
                    'api_key_length' => strlen($OPENAI_API_KEY),
                    'api_key_prefix' => substr($OPENAI_API_KEY, 0, 20),
                    'model' => $model,
                    'provider' => $provider
                ]
            ]);
            exit();
        }
        
        $responseData = json_decode($response, true);
        
        if (isset($responseData['choices'][0]['message']['content'])) {
            $aiResponse = $responseData['choices'][0]['message']['content'];
            $usage = $responseData['usage'] ?? [];
            $inputTokens = $usage['prompt_tokens'] ?? 0;
            $outputTokens = $usage['completion_tokens'] ?? 0;
        } else {
            http_response_code(500);
            echo json_encode([
                'error' => 'Risposta non valida da OpenAI API',
                'details' => $responseData
            ]);
            exit();
        }
    }
    
    // Calcola e logga il costo (comune per entrambi i provider)
    $cost = calculateCost($inputTokens, $outputTokens, $model);
    logUsage($inputTokens + $outputTokens, $model, $cost);
    
    // Calcola costi mensili
    $monthlyLogs = [];
    $monthlyLogFile = $LOG_DIR . 'ai_usage_' . date('Y-m') . '.json';
    if (file_exists($monthlyLogFile)) {
        $monthlyLogs = json_decode(file_get_contents($monthlyLogFile), true) ?: [];
    }
    
    $monthlyCost = array_sum(array_column($monthlyLogs, 'cost'));
    $dailyCost = array_sum(array_column(array_filter($monthlyLogs, function($log) {
        return date('Y-m-d', strtotime($log['timestamp'])) === date('Y-m-d');
    }), 'cost'));
    
    // Pulisci la risposta da eventuali prefissi indesiderati
    $cleanResponse = preg_replace('/^\*[^*]*\*\s*/', '', $aiResponse);
    $cleanResponse = preg_replace('/^\*risponde in forma testuale\*\s*/i', '', $cleanResponse);
    $cleanResponse = preg_replace('/^\*[^*]*modalità[^*]*\*\s*/i', '', $cleanResponse);
    
    echo json_encode([
        'success' => true,
        'response' => $cleanResponse,
        'provider' => $provider,
        'usage' => [
            'input_tokens' => $inputTokens,
            'output_tokens' => $outputTokens,
            'total_tokens' => $inputTokens + $outputTokens,
            'cost' => $cost,
            'daily_cost' => round($dailyCost, 2),
            'monthly_cost' => round($monthlyCost, 2)
        ],
        'model' => $model
    ]);
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Metodo non permesso']);
}